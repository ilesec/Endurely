#!/bin/bash

# Startup script for Azure App Services
echo "Starting Endurely..."

# Try to create database if it doesn't exist (but don't fail if it can't connect yet)
python -c "try:
    from app.database import init_db
    init_db()
    print('Database initialized successfully')
except Exception as e:
    print(f'Database initialization skipped: {e}')
    print('App will attempt to initialize on first request')
" || true

# Get PORT from Azure environment variable (defaults to 8000)
PORT="${PORT:-8000}"

# Start the application with gunicorn
# - Use a longer timeout for LLM calls
# - Use a single worker to reduce memory pressure on smaller App Service plans
gunicorn app.main:app --workers 1 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:$PORT --timeout 600 --access-logfile - --error-logfile -
